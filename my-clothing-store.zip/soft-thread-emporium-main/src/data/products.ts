import sweater from "@/assets/product-sweater.jpg";
import trousers from "@/assets/product-trousers.jpg";
import coat from "@/assets/product-coat.jpg";
import dress from "@/assets/product-dress.jpg";
import tee from "@/assets/product-tee.jpg";
import cardigan from "@/assets/product-cardigan.jpg";

export type Product = {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  sizes: string[];
  category: "Knitwear" | "Outerwear" | "Dresses" | "Trousers" | "Tops";
  likes: number;
  story: string;
};

export const products: Product[] = [
  {
    id: "ivory-cashmere",
    name: "Ivory Cashmere Knit",
    description: "A relaxed crewneck spun from grade-A Mongolian cashmere. Designed to soften with every wear.",
    price: 380,
    image: sweater,
    sizes: ["XS", "S", "M", "L"],
    category: "Knitwear",
    likes: 248,
    story: "Hand-finished in a small atelier outside Florence.",
  },
  {
    id: "sand-trouser",
    name: "Sand Linen Trouser",
    description: "Wide-leg, high-rise. Cut from heavyweight Belgian linen that drapes like a memory.",
    price: 285,
    image: trousers,
    sizes: ["24", "26", "28", "30", "32"],
    category: "Trousers",
    likes: 189,
    story: "Belgian linen, washed for an heirloom hand-feel.",
  },
  {
    id: "camel-coat",
    name: "Camel Atelier Coat",
    description: "A single-breasted topcoat in pure virgin wool. The piece you'll wear every winter for a decade.",
    price: 890,
    image: coat,
    sizes: ["XS", "S", "M", "L"],
    category: "Outerwear",
    likes: 412,
    story: "Tailored in northern Italy from a 28-step process.",
  },
  {
    id: "terracotta-slip",
    name: "Terracotta Silk Slip",
    description: "Bias-cut silk charmeuse in a sun-warmed clay tone. Weightless on, lasting on the eye.",
    price: 420,
    image: dress,
    sizes: ["XS", "S", "M", "L"],
    category: "Dresses",
    likes: 367,
    story: "100% mulberry silk, naturally dyed in small batches.",
  },
  {
    id: "essential-tee",
    name: "Essential Cotton Tee",
    description: "Boxy, cropped, in featherweight organic cotton. The quiet anchor of any wardrobe.",
    price: 95,
    image: tee,
    sizes: ["XS", "S", "M", "L"],
    category: "Tops",
    likes: 521,
    story: "GOTS-certified organic cotton, knit in Portugal.",
  },
  {
    id: "sage-cardigan",
    name: "Sage Merino Cardigan",
    description: "A featherweight merino cardigan in a soft botanical sage. Layer over everything.",
    price: 295,
    image: cardigan,
    sizes: ["XS", "S", "M", "L"],
    category: "Knitwear",
    likes: 278,
    story: "Spun from extra-fine merino, plant-dyed.",
  },
];

export const categories = ["All", "Knitwear", "Outerwear", "Dresses", "Trousers", "Tops"] as const;
export const allSizes = ["XS", "S", "M", "L", "24", "26", "28", "30", "32"];
