import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import hero from "@/assets/hero.jpg";
import look2 from "@/assets/look-2.jpg";
import { products } from "@/data/products";
import { ProductCard } from "@/components/ProductCard";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

const Index = () => {
  const featured = products.slice(0, 4);
  const trending = [...products].sort((a, b) => b.likes - a.likes).slice(0, 3);

  return (
    <Layout>
      {/* Hero */}
      <section className="relative">
        <div className="relative h-[88vh] min-h-[600px] overflow-hidden">
          <img src={hero} alt="Maison Lune SS collection" className="absolute inset-0 w-full h-full object-cover" width={1080} height={1920} />
          <div className="absolute inset-0 bg-gradient-hero" />
          <div className="absolute inset-0 container-editorial flex items-end pb-16 md:pb-24">
            <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }} className="max-w-xl">
              <div className="eyebrow mb-4">Spring / Summer · Volume I</div>
              <h1 className="font-serif text-5xl md:text-7xl lg:text-8xl leading-[0.95] mb-6">
                Soft hours,<br /><em className="not-italic text-accent">slow-made.</em>
              </h1>
              <p className="text-base md:text-lg text-muted-foreground max-w-md mb-8 leading-relaxed">
                A small collection of seven pieces, sewn close to home. Linens that loosen, knits that soften, the wardrobe of an unhurried life.
              </p>
              <Button size="lg" asChild>
                <Link to="/shop">Shop the collection <ArrowRight className="ml-2 w-4 h-4" /></Link>
              </Button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Marquee values */}
      <section className="overflow-hidden border-y border-border/60 py-6 bg-secondary/40">
        <div className="flex animate-marquee whitespace-nowrap">
          {[...Array(2)].map((_, k) => (
            <div key={k} className="flex items-center gap-16 px-8 font-serif text-2xl md:text-3xl">
              {["Slow-made in Europe", "Natural fibres only", "Seven pieces, no more", "Designed in Lisbon", "Plant-dyed", "Made to last"].map((t, i) => (
                <span key={i} className="flex items-center gap-16">
                  <span className="text-muted-foreground italic">{t}</span>
                  <span className="text-accent">·</span>
                </span>
              ))}
            </div>
          ))}
        </div>
      </section>

      {/* Featured */}
      <section className="container-editorial py-24 md:py-32">
        <div className="flex items-end justify-between mb-12 md:mb-16">
          <div>
            <div className="eyebrow mb-3">The collection</div>
            <h2 className="font-serif text-4xl md:text-5xl">Pieces to live in.</h2>
          </div>
          <Link to="/shop" className="hidden md:inline-block link-underline text-sm">View all</Link>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-5 gap-y-12">
          {featured.map((p, i) => (
            <motion.div key={p.id} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-80px" }} transition={{ duration: 0.7, delay: i * 0.08, ease: [0.22, 1, 0.36, 1] }}>
              <ProductCard product={p} />
            </motion.div>
          ))}
        </div>
      </section>

      {/* Brand intro split */}
      <section className="container-editorial py-24 md:py-32">
        <div className="grid md:grid-cols-2 gap-10 md:gap-20 items-center">
          <motion.img initial={{ opacity: 0, scale: 1.04 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ duration: 1.1 }} src={look2} alt="Behind the collection" className="w-full aspect-[4/5] object-cover rounded-md" loading="lazy" />
          <div>
            <div className="eyebrow mb-4">Behind Maison Lune</div>
            <h2 className="font-serif text-4xl md:text-5xl leading-tight mb-6">A wardrobe that whispers.</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              I started Maison Lune from a small apartment in Lisbon, frustrated by the noise of fast fashion. Each piece is drawn by hand, prototyped three times, and produced in batches of fewer than a hundred.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              The result is clothing that asks nothing of you — quiet enough to wear daily, considered enough to last decades.
            </p>
            <Link to="/story" className="link-underline text-sm">Read the story</Link>
          </div>
        </div>
      </section>

      {/* Trending */}
      <section className="container-editorial py-24 md:py-32 bg-secondary/30 -mx-6 md:-mx-10 lg:-mx-16 px-6 md:px-10 lg:px-16 rounded-none">
        <div className="text-center mb-12">
          <div className="eyebrow mb-3">Most loved</div>
          <h2 className="font-serif text-4xl md:text-5xl">Trending this week.</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-x-5 gap-y-12">
          {trending.map(p => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>
    </Layout>
  );
};

export default Index;
