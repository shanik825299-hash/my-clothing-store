import { Layout } from "@/components/layout/Layout";
import { useShop } from "@/context/ShopContext";
import { products } from "@/data/products";
import { ProductCard } from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const Wishlist = () => {
  const { wishlist } = useShop();
  const items = products.filter(p => wishlist.includes(p.id));

  return (
    <Layout>
      <div className="container-editorial py-16 md:py-24">
        <div className="eyebrow mb-3">Saved</div>
        <h1 className="font-serif text-5xl md:text-6xl mb-12">Wishlist</h1>
        {items.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-muted-foreground mb-6">No saved pieces yet.</p>
            <Button asChild><Link to="/shop">Browse the collection</Link></Button>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-5 gap-y-12">
            {items.map(p => <ProductCard key={p.id} product={p} />)}
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Wishlist;
