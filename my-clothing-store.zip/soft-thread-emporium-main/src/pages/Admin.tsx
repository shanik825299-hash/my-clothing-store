import { Layout } from "@/components/layout/Layout";
import { useState } from "react";
import { products as initial, Product } from "@/data/products";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Pencil, Trash2, Plus, X } from "lucide-react";

const blank = (): Product => ({
  id: "", name: "", description: "", price: 0, image: "", sizes: ["S", "M", "L"], category: "Tops", likes: 0, story: "",
});

const Admin = () => {
  const [list, setList] = useState<Product[]>(initial);
  const [editing, setEditing] = useState<Product | null>(null);

  const save = () => {
    if (!editing) return;
    if (!editing.name || !editing.price) { toast.error("Name and price required"); return; }
    setList(prev => {
      const exists = prev.find(p => p.id === editing.id);
      if (exists) return prev.map(p => p.id === editing.id ? editing : p);
      return [...prev, { ...editing, id: editing.id || crypto.randomUUID() }];
    });
    toast.success("Saved (session only — connect Lovable Cloud to persist)");
    setEditing(null);
  };

  const remove = (id: string) => {
    setList(prev => prev.filter(p => p.id !== id));
    toast.success("Removed");
  };

  const handleImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !editing) return;
    const reader = new FileReader();
    reader.onload = () => setEditing({ ...editing, image: reader.result as string });
    reader.readAsDataURL(file);
  };

  return (
    <Layout>
      <div className="container-editorial py-12 md:py-16">
        <div className="flex items-end justify-between mb-10">
          <div>
            <div className="eyebrow mb-3">Atelier</div>
            <h1 className="font-serif text-4xl md:text-5xl">Admin</h1>
            <p className="text-sm text-muted-foreground mt-2">Manage the collection. Demo storage — connect Lovable Cloud for persistence.</p>
          </div>
          <Button onClick={() => setEditing(blank())}><Plus className="w-4 h-4 mr-2" />New piece</Button>
        </div>

        <div className="overflow-x-auto border border-border rounded-md">
          <table className="w-full text-sm">
            <thead className="bg-secondary/40 text-left">
              <tr>
                <th className="p-4 font-medium">Piece</th>
                <th className="p-4 font-medium">Category</th>
                <th className="p-4 font-medium">Price</th>
                <th className="p-4 font-medium">Sizes</th>
                <th className="p-4 font-medium w-24"></th>
              </tr>
            </thead>
            <tbody>
              {list.map(p => (
                <tr key={p.id} className="border-t border-border">
                  <td className="p-4 flex items-center gap-3">
                    <img src={p.image} alt="" className="w-12 h-14 object-cover rounded bg-muted" />
                    <span className="font-serif text-base">{p.name}</span>
                  </td>
                  <td className="p-4 text-muted-foreground">{p.category}</td>
                  <td className="p-4 tabular-nums">${p.price}</td>
                  <td className="p-4 text-muted-foreground text-xs">{p.sizes.join(", ")}</td>
                  <td className="p-4">
                    <div className="flex gap-1 justify-end">
                      <Button size="icon" variant="ghost" onClick={() => setEditing(p)}><Pencil className="w-4 h-4" /></Button>
                      <Button size="icon" variant="ghost" onClick={() => remove(p.id)}><Trash2 className="w-4 h-4" /></Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {editing && (
        <div className="fixed inset-0 z-50 bg-foreground/40 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setEditing(null)}>
          <div className="bg-background rounded-lg max-w-xl w-full max-h-[90vh] overflow-y-auto shadow-card" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between p-6 border-b border-border">
              <h2 className="font-serif text-2xl">{editing.id ? "Edit piece" : "New piece"}</h2>
              <button onClick={() => setEditing(null)}><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              <Input placeholder="Name" value={editing.name} onChange={e => setEditing({ ...editing, name: e.target.value })} />
              <Textarea placeholder="Description" value={editing.description} onChange={e => setEditing({ ...editing, description: e.target.value })} />
              <div className="grid grid-cols-2 gap-3">
                <Input type="number" placeholder="Price" value={editing.price || ""} onChange={e => setEditing({ ...editing, price: Number(e.target.value) })} />
                <select className="h-10 border border-input bg-transparent rounded-md px-3 text-sm" value={editing.category} onChange={e => setEditing({ ...editing, category: e.target.value as any })}>
                  {["Knitwear", "Outerwear", "Dresses", "Trousers", "Tops"].map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
              <Input placeholder="Sizes (comma separated)" value={editing.sizes.join(",")} onChange={e => setEditing({ ...editing, sizes: e.target.value.split(",").map(s => s.trim()) })} />
              <Textarea placeholder="From the maker" value={editing.story} onChange={e => setEditing({ ...editing, story: e.target.value })} />
              <div>
                <label className="eyebrow mb-2 block">Image</label>
                <input type="file" accept="image/*" onChange={handleImage} className="text-sm" />
                {editing.image && <img src={editing.image} alt="" className="mt-3 w-32 h-40 object-cover rounded bg-muted" />}
              </div>
            </div>
            <div className="p-6 border-t border-border flex justify-end gap-3">
              <Button variant="ghost" onClick={() => setEditing(null)}>Cancel</Button>
              <Button onClick={save}>Save piece</Button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default Admin;
