import { Layout } from "@/components/layout/Layout";
import { motion } from "framer-motion";
import look1 from "@/assets/look-1.jpg";
import look2 from "@/assets/look-2.jpg";
import look3 from "@/assets/look-3.jpg";
import { products } from "@/data/products";
import { Link } from "react-router-dom";

const looks = [
  { img: look1, title: "Sun-bleached Suiting", subtitle: "Look 01", items: ["sand-trouser", "essential-tee"] },
  { img: look2, title: "Evening, Slowed", subtitle: "Look 02", items: ["terracotta-slip", "camel-coat"] },
  { img: look3, title: "Quiet Layers", subtitle: "Look 03", items: ["sage-cardigan", "essential-tee", "sand-trouser"] },
];

const Lookbook = () => (
  <Layout>
    <section className="container-editorial pt-16 md:pt-24 pb-12 text-center max-w-2xl mx-auto">
      <div className="eyebrow mb-4">Volume I · Spring</div>
      <h1 className="font-serif text-5xl md:text-7xl leading-[1] mb-6">The Lookbook.</h1>
      <p className="text-muted-foreground leading-relaxed">
        Three studies in proportion, light, and earth. Pieces styled the way they were imagined.
      </p>
    </section>

    <div className="space-y-24 md:space-y-40 pb-20">
      {looks.map((look, i) => (
        <motion.section
          key={look.subtitle}
          initial={{ opacity: 0, y: 60 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
          className={`container-editorial grid md:grid-cols-12 gap-8 md:gap-12 items-center ${i % 2 ? "md:[&>*:first-child]:order-2" : ""}`}
        >
          <div className="md:col-span-7">
            <img src={look.img} alt={look.title} className="w-full aspect-[4/5] object-cover rounded-md" loading="lazy" />
          </div>
          <div className="md:col-span-5 md:px-8">
            <div className="eyebrow mb-3">{look.subtitle}</div>
            <h2 className="font-serif text-4xl md:text-5xl mb-6 leading-tight">{look.title}</h2>
            <div className="space-y-3 mb-6">
              {look.items.map(id => {
                const p = products.find(x => x.id === id);
                if (!p) return null;
                return (
                  <Link key={id} to={`/product/${id}`} className="flex items-center justify-between py-3 border-b border-border group">
                    <div>
                      <div className="font-serif text-lg">{p.name}</div>
                      <div className="text-xs text-muted-foreground uppercase tracking-wider mt-0.5">{p.category}</div>
                    </div>
                    <div className="text-sm tabular-nums group-hover:text-accent transition-colors">${p.price} →</div>
                  </Link>
                );
              })}
            </div>
          </div>
        </motion.section>
      ))}
    </div>
  </Layout>
);

export default Lookbook;
