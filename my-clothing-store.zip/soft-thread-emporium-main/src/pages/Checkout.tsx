import { Layout } from "@/components/layout/Layout";
import { useShop } from "@/context/ShopContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Check } from "lucide-react";

const Checkout = () => {
  const { cart, cartTotal } = useShop();
  const [done, setDone] = useState(false);
  const navigate = useNavigate();

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setDone(true);
    toast.success("Order placed — a quiet thank you.");
  };

  if (done) {
    return (
      <Layout>
        <div className="container-editorial py-32 text-center max-w-lg mx-auto">
          <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mx-auto mb-6"><Check className="w-7 h-7 text-accent" /></div>
          <h1 className="font-serif text-5xl mb-4">Thank you.</h1>
          <p className="text-muted-foreground mb-8">A confirmation is on its way. Your pieces will be packed slowly and posted within three working days.</p>
          <Button onClick={() => navigate("/")}>Return home</Button>
        </div>
      </Layout>
    );
  }

  if (cart.length === 0) {
    return (
      <Layout>
        <div className="container-editorial py-32 text-center">
          <h1 className="font-serif text-4xl mb-4">Your bag is empty.</h1>
          <Button asChild><Link to="/shop">Browse the collection</Link></Button>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container-editorial py-16 grid lg:grid-cols-[1fr_400px] gap-16">
        <div>
          <h1 className="font-serif text-4xl md:text-5xl mb-10">Checkout</h1>
          <form onSubmit={submit} className="space-y-8">
            <fieldset className="space-y-4">
              <legend className="eyebrow mb-3">Contact</legend>
              <Input required type="email" placeholder="Email" />
            </fieldset>
            <fieldset className="space-y-4">
              <legend className="eyebrow mb-3">Shipping</legend>
              <div className="grid grid-cols-2 gap-3">
                <Input required placeholder="First name" />
                <Input required placeholder="Last name" />
              </div>
              <Input required placeholder="Address" />
              <div className="grid grid-cols-2 gap-3">
                <Input required placeholder="City" />
                <Input required placeholder="Postal code" />
              </div>
              <Input required placeholder="Country" defaultValue="Portugal" />
            </fieldset>
            <fieldset className="space-y-4">
              <legend className="eyebrow mb-3">Payment</legend>
              <Input required placeholder="Card number" />
              <div className="grid grid-cols-2 gap-3">
                <Input required placeholder="MM / YY" />
                <Input required placeholder="CVC" />
              </div>
              <p className="text-xs text-muted-foreground">Demo checkout — no card will be charged.</p>
            </fieldset>
            <Button type="submit" size="lg" className="w-full">Place order · ${cartTotal}</Button>
          </form>
        </div>

        <aside className="bg-secondary/40 rounded-md p-6 h-fit lg:sticky lg:top-24">
          <h2 className="font-serif text-xl mb-5">Order summary</h2>
          <ul className="space-y-4 mb-5">
            {cart.map(i => (
              <li key={i.product.id + i.size} className="flex gap-3 text-sm">
                <img src={i.product.image} alt="" className="w-14 h-16 object-cover rounded bg-muted" />
                <div className="flex-1">
                  <div className="font-serif text-base">{i.product.name}</div>
                  <div className="text-xs text-muted-foreground">Size {i.size} · Qty {i.qty}</div>
                </div>
                <div className="tabular-nums">${i.product.price * i.qty}</div>
              </li>
            ))}
          </ul>
          <div className="border-t border-border pt-4 space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span className="tabular-nums">${cartTotal}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Shipping</span><span>Free</span></div>
            <div className="flex justify-between font-medium pt-2 border-t border-border"><span>Total</span><span className="tabular-nums">${cartTotal}</span></div>
          </div>
        </aside>
      </div>
    </Layout>
  );
};

export default Checkout;
