import { Layout } from "@/components/layout/Layout";
import story from "@/assets/story.jpg";
import look1 from "@/assets/look-1.jpg";
import { motion } from "framer-motion";

const Story = () => (
  <Layout>
    <section className="container-editorial pt-20 md:pt-32 pb-16 max-w-3xl">
      <div className="eyebrow mb-4">Behind the collection</div>
      <h1 className="font-serif text-5xl md:text-7xl leading-[1] mb-8">Made by hand,<br /><em>made to last.</em></h1>
      <p className="text-lg text-muted-foreground leading-relaxed">
        Maison Lune began as a private wardrobe — pieces I drew for myself when I couldn't find them. A coat that fit. A trouser that fell right. A knit that didn't pill in a season.
      </p>
    </section>

    <motion.img initial={{ opacity: 0, scale: 1.05 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ duration: 1.2 }} src={story} alt="Atelier" className="w-full h-[60vh] object-cover" />

    <section className="container-editorial py-20 md:py-28 grid md:grid-cols-2 gap-16">
      <div className="space-y-6 text-muted-foreground leading-relaxed">
        <h2 className="font-serif text-3xl md:text-4xl text-foreground">A small house, on purpose.</h2>
        <p>We make seven pieces a season. No more. Each is prototyped three times, fitted on three bodies, then produced in batches of fewer than a hundred in family-run ateliers across Portugal and Italy.</p>
        <p>The materials are simple: linen, merino, cashmere, silk, cotton. The dyes are plant-based where possible. The buttons are corozo, the threads are GOTS-certified.</p>
      </div>
      <div className="space-y-6 text-muted-foreground leading-relaxed">
        <h2 className="font-serif text-3xl md:text-4xl text-foreground">The unhurried life.</h2>
        <p>I believe a wardrobe should make mornings easier, not louder. The pieces here are designed to layer, repeat, and quietly outlast the trend cycle.</p>
        <p>If you find one that becomes yours — wear it for years. Mend it. Pass it on. That is the only success we measure.</p>
        <div className="pt-4 font-serif text-xl italic text-foreground">— Lune</div>
      </div>
    </section>

    <section className="container-editorial pb-32 grid md:grid-cols-3 gap-6">
      {[
        ["01", "Drawn", "Each piece begins on paper, in my studio in Lisbon."],
        ["02", "Made", "Sewn by hand in family ateliers across Europe."],
        ["03", "Worn", "Yours to keep — and, we hope, to repair and pass on."],
      ].map(([n, t, d]) => (
        <div key={n} className="border-t border-border pt-6">
          <div className="font-serif text-3xl text-accent mb-3">{n}</div>
          <div className="font-serif text-2xl mb-2">{t}</div>
          <p className="text-sm text-muted-foreground leading-relaxed">{d}</p>
        </div>
      ))}
    </section>
  </Layout>
);

export default Story;
