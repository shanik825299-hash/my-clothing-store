import { useMemo, useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { ProductCard } from "@/components/ProductCard";
import { products, categories, allSizes } from "@/data/products";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { cn } from "@/lib/utils";
import { Search } from "lucide-react";

const Shop = () => {
  const [params, setParams] = useSearchParams();
  const initialCat = (params.get("cat") as any) || "All";
  const [cat, setCat] = useState<string>(initialCat);
  const [sizes, setSizes] = useState<string[]>([]);
  const [price, setPrice] = useState<[number, number]>([0, 1000]);
  const [q, setQ] = useState("");

  useEffect(() => {
    if (cat === "All") params.delete("cat"); else params.set("cat", cat);
    setParams(params, { replace: true });
  }, [cat]);

  const filtered = useMemo(() => products.filter(p => {
    if (cat !== "All" && p.category !== cat) return false;
    if (sizes.length && !sizes.some(s => p.sizes.includes(s))) return false;
    if (p.price < price[0] || p.price > price[1]) return false;
    if (q && !p.name.toLowerCase().includes(q.toLowerCase()) && !p.description.toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  }), [cat, sizes, price, q]);

  const toggleSize = (s: string) => setSizes(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]);

  return (
    <Layout>
      <div className="container-editorial pt-12 md:pt-16 pb-8">
        <div className="eyebrow mb-3">The collection</div>
        <h1 className="font-serif text-5xl md:text-6xl">Shop all</h1>
      </div>

      <div className="container-editorial grid lg:grid-cols-[240px_1fr] gap-10 lg:gap-16 pb-20">
        {/* Filters */}
        <aside className="space-y-8 lg:sticky lg:top-24 lg:self-start">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search" value={q} onChange={e => setQ(e.target.value)} className="pl-9 bg-transparent" />
          </div>

          <div>
            <div className="eyebrow mb-4">Category</div>
            <ul className="space-y-2">
              {categories.map(c => (
                <li key={c}>
                  <button onClick={() => setCat(c)} className={cn("text-sm transition-colors", cat === c ? "text-accent" : "text-muted-foreground hover:text-foreground")}>
                    {c}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <div className="eyebrow mb-4">Size</div>
            <div className="flex flex-wrap gap-2">
              {allSizes.map(s => (
                <button key={s} onClick={() => toggleSize(s)} className={cn("min-w-[40px] h-9 px-3 text-xs border rounded-full transition-colors", sizes.includes(s) ? "bg-foreground text-background border-foreground" : "border-border hover:border-foreground")}>
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="eyebrow mb-4">Price · ${price[0]} – ${price[1]}</div>
            <Slider min={0} max={1000} step={10} value={price} onValueChange={v => setPrice(v as [number, number])} />
          </div>
        </aside>

        <div>
          <div className="text-xs text-muted-foreground mb-6">{filtered.length} {filtered.length === 1 ? "piece" : "pieces"}</div>
          {filtered.length === 0 ? (
            <p className="text-muted-foreground">Nothing matches — try widening the search.</p>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-x-5 gap-y-12">
              {filtered.map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default Shop;
