import { useParams, Link } from "react-router-dom";
import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { products } from "@/data/products";
import { Button } from "@/components/ui/button";
import { Heart, MessageCircle, Send } from "lucide-react";
import { useShop } from "@/context/ShopContext";
import { cn } from "@/lib/utils";
import { ProductCard } from "@/components/ProductCard";
import { toast } from "sonner";

type Comment = { id: string; name: string; text: string; at: number };

const Product = () => {
  const { id } = useParams();
  const product = products.find(p => p.id === id);
  const { addToCart, toggleWishlist, wishlist, toggleLike, liked, likes } = useShop();
  const [size, setSize] = useState<string>("");
  const [comments, setComments] = useState<Comment[]>(() => {
    try { return JSON.parse(localStorage.getItem(`ml-comments-${id}`) || "[]"); } catch { return []; }
  });
  const [name, setName] = useState("");
  const [text, setText] = useState("");

  if (!product) return <Layout><div className="container-editorial py-32 text-center"><h1 className="font-serif text-4xl">Not found</h1><Link to="/shop" className="link-underline mt-4 inline-block">Back to shop</Link></div></Layout>;

  const inWish = wishlist.includes(product.id);
  const isLiked = liked.has(product.id);
  const totalLikes = product.likes + (likes[product.id] || 0);

  const handleAdd = () => {
    if (!size) { toast.error("Please select a size"); return; }
    addToCart(product, size);
  };

  const submitComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !text) return;
    const next = [{ id: crypto.randomUUID(), name, text, at: Date.now() }, ...comments];
    setComments(next);
    localStorage.setItem(`ml-comments-${id}`, JSON.stringify(next));
    setText(""); setName("");
  };

  const related = products.filter(p => p.id !== product.id && p.category === product.category).slice(0, 3);

  return (
    <Layout>
      <div className="container-editorial pt-8 pb-20">
        <Link to="/shop" className="text-xs text-muted-foreground link-underline">← Back</Link>

        <div className="grid md:grid-cols-2 gap-10 md:gap-16 mt-6">
          <div className="bg-muted rounded-md overflow-hidden aspect-[4/5]">
            <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
          </div>

          <div className="md:py-8">
            <div className="eyebrow mb-3">{product.category}</div>
            <h1 className="font-serif text-4xl md:text-5xl mb-3 leading-tight">{product.name}</h1>
            <div className="text-xl tabular-nums mb-6">${product.price}</div>
            <p className="text-muted-foreground leading-relaxed mb-8">{product.description}</p>

            <div className="mb-8">
              <div className="flex items-center justify-between mb-3">
                <div className="eyebrow">Size</div>
                <button className="text-xs text-muted-foreground link-underline">Size guide</button>
              </div>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map(s => (
                  <button key={s} onClick={() => setSize(s)} className={cn("min-w-[52px] h-11 px-4 border rounded-full text-sm transition-colors", size === s ? "bg-foreground text-background border-foreground" : "border-border hover:border-foreground")}>
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex gap-3 mb-8">
              <Button size="lg" className="flex-1" onClick={handleAdd}>Add to bag</Button>
              <Button size="lg" variant="outline" onClick={() => toggleWishlist(product.id)} aria-label="Wishlist">
                <Heart className={cn("w-4 h-4", inWish && "fill-accent text-accent")} />
              </Button>
            </div>

            <button onClick={() => toggleLike(product.id)} className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-accent transition-colors mb-8">
              <Heart className={cn("w-4 h-4", isLiked && "fill-accent text-accent")} />
              {totalLikes} loves this piece
            </button>

            <div className="border-t border-border pt-6 space-y-3 text-sm text-muted-foreground">
              <div><span className="text-foreground font-medium">From the maker:</span> {product.story}</div>
              <div>Free shipping on orders over $250 · Easy returns within 30 days</div>
            </div>
          </div>
        </div>

        {/* Comments */}
        <section className="mt-24 max-w-2xl">
          <div className="flex items-center gap-2 mb-6">
            <MessageCircle className="w-4 h-4" />
            <h2 className="font-serif text-2xl">Conversation ({comments.length})</h2>
          </div>
          <form onSubmit={submitComment} className="space-y-3 mb-8">
            <input value={name} onChange={e => setName(e.target.value)} placeholder="Your name" className="w-full bg-transparent border-b border-border py-2 text-sm focus:outline-none focus:border-foreground" />
            <div className="flex gap-2">
              <input value={text} onChange={e => setText(e.target.value)} placeholder="Share a thought…" className="flex-1 bg-transparent border-b border-border py-2 text-sm focus:outline-none focus:border-foreground" />
              <Button type="submit" size="sm" variant="ghost"><Send className="w-4 h-4" /></Button>
            </div>
          </form>
          <ul className="space-y-5">
            {comments.map(c => (
              <li key={c.id} className="text-sm">
                <div className="flex items-baseline gap-2">
                  <span className="font-medium">{c.name}</span>
                  <span className="text-xs text-muted-foreground">{new Date(c.at).toLocaleDateString()}</span>
                </div>
                <p className="text-muted-foreground mt-1">{c.text}</p>
              </li>
            ))}
            {comments.length === 0 && <li className="text-sm text-muted-foreground italic">Be the first to write.</li>}
          </ul>
        </section>

        {related.length > 0 && (
          <section className="mt-24">
            <h2 className="font-serif text-3xl mb-8">You may also love</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-x-5 gap-y-12">
              {related.map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          </section>
        )}
      </div>
    </Layout>
  );
};

export default Product;
