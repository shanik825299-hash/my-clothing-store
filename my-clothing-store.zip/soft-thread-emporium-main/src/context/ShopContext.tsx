import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { Product } from "@/data/products";

export type CartItem = { product: Product; size: string; qty: number };

type ShopContextType = {
  cart: CartItem[];
  wishlist: string[];
  likes: Record<string, number>;
  liked: Set<string>;
  cartOpen: boolean;
  setCartOpen: (v: boolean) => void;
  addToCart: (product: Product, size: string) => void;
  removeFromCart: (id: string, size: string) => void;
  updateQty: (id: string, size: string, qty: number) => void;
  toggleWishlist: (id: string) => void;
  toggleLike: (id: string) => void;
  cartTotal: number;
  cartCount: number;
};

const ShopContext = createContext<ShopContextType | null>(null);

const load = <T,>(key: string, fallback: T): T => {
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : fallback;
  } catch {
    return fallback;
  }
};

export const ShopProvider = ({ children }: { children: ReactNode }) => {
  const [cart, setCart] = useState<CartItem[]>(() => load("ml-cart", []));
  const [wishlist, setWishlist] = useState<string[]>(() => load("ml-wish", []));
  const [likes, setLikes] = useState<Record<string, number>>(() => load("ml-likes", {}));
  const [liked, setLiked] = useState<Set<string>>(() => new Set(load<string[]>("ml-liked", [])));
  const [cartOpen, setCartOpen] = useState(false);

  useEffect(() => { localStorage.setItem("ml-cart", JSON.stringify(cart)); }, [cart]);
  useEffect(() => { localStorage.setItem("ml-wish", JSON.stringify(wishlist)); }, [wishlist]);
  useEffect(() => { localStorage.setItem("ml-likes", JSON.stringify(likes)); }, [likes]);
  useEffect(() => { localStorage.setItem("ml-liked", JSON.stringify([...liked])); }, [liked]);

  const addToCart = (product: Product, size: string) => {
    setCart(prev => {
      const i = prev.findIndex(x => x.product.id === product.id && x.size === size);
      if (i >= 0) {
        const copy = [...prev];
        copy[i] = { ...copy[i], qty: copy[i].qty + 1 };
        return copy;
      }
      return [...prev, { product, size, qty: 1 }];
    });
    setCartOpen(true);
  };

  const removeFromCart = (id: string, size: string) =>
    setCart(prev => prev.filter(x => !(x.product.id === id && x.size === size)));

  const updateQty = (id: string, size: string, qty: number) =>
    setCart(prev => prev.map(x => (x.product.id === id && x.size === size ? { ...x, qty: Math.max(1, qty) } : x)));

  const toggleWishlist = (id: string) =>
    setWishlist(prev => (prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]));

  const toggleLike = (id: string) => {
    setLiked(prev => {
      const next = new Set(prev);
      const isLiked = next.has(id);
      if (isLiked) next.delete(id); else next.add(id);
      setLikes(l => ({ ...l, [id]: (l[id] || 0) + (isLiked ? -1 : 1) }));
      return next;
    });
  };

  const cartTotal = cart.reduce((s, x) => s + x.product.price * x.qty, 0);
  const cartCount = cart.reduce((s, x) => s + x.qty, 0);

  return (
    <ShopContext.Provider value={{ cart, wishlist, likes, liked, cartOpen, setCartOpen, addToCart, removeFromCart, updateQty, toggleWishlist, toggleLike, cartTotal, cartCount }}>
      {children}
    </ShopContext.Provider>
  );
};

export const useShop = () => {
  const ctx = useContext(ShopContext);
  if (!ctx) throw new Error("useShop must be used inside ShopProvider");
  return ctx;
};
