import { Link } from "react-router-dom";
import { Heart } from "lucide-react";
import { Product } from "@/data/products";
import { useShop } from "@/context/ShopContext";
import { cn } from "@/lib/utils";

export const ProductCard = ({ product }: { product: Product }) => {
  const { wishlist, toggleWishlist, likes, liked, toggleLike } = useShop();
  const inWish = wishlist.includes(product.id);
  const totalLikes = product.likes + (likes[product.id] || 0);
  const isLiked = liked.has(product.id);

  return (
    <article className="product-card group">
      <div className="product-card-img">
        <Link to={`/product/${product.id}`}>
          <img src={product.image} alt={product.name} loading="lazy" width={1024} height={1280} />
        </Link>
        <button
          onClick={() => toggleWishlist(product.id)}
          className="absolute top-3 right-3 w-9 h-9 rounded-full bg-background/80 backdrop-blur flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:bg-background"
          aria-label="Wishlist"
        >
          <Heart className={cn("w-4 h-4 transition-colors", inWish && "fill-accent text-accent")} />
        </button>
      </div>
      <div className="mt-4 flex items-start justify-between gap-3">
        <div>
          <Link to={`/product/${product.id}`} className="block">
            <h3 className="font-serif text-lg leading-tight">{product.name}</h3>
          </Link>
          <div className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground mt-1">{product.category}</div>
        </div>
        <div className="text-sm tabular-nums">${product.price}</div>
      </div>
      <button
        onClick={() => toggleLike(product.id)}
        className="mt-2 inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-accent transition-colors"
      >
        <Heart className={cn("w-3 h-3", isLiked && "fill-accent text-accent")} />
        {totalLikes}
      </button>
    </article>
  );
};
