import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { useShop } from "@/context/ShopContext";
import { Button } from "@/components/ui/button";
import { Minus, Plus, X } from "lucide-react";
import { Link } from "react-router-dom";

export const CartDrawer = () => {
  const { cartOpen, setCartOpen, cart, removeFromCart, updateQty, cartTotal } = useShop();

  return (
    <Sheet open={cartOpen} onOpenChange={setCartOpen}>
      <SheetContent className="w-full sm:max-w-md flex flex-col p-0">
        <SheetHeader className="px-6 py-5 border-b border-border/60">
          <SheetTitle className="font-serif text-2xl text-left">Your bag</SheetTitle>
        </SheetHeader>

        {cart.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center px-6 gap-4">
            <p className="text-muted-foreground">Your bag is quiet.</p>
            <Button variant="outline" onClick={() => setCartOpen(false)} asChild>
              <Link to="/shop">Browse the collection</Link>
            </Button>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-5">
              {cart.map(item => (
                <div key={item.product.id + item.size} className="flex gap-4">
                  <img src={item.product.image} alt={item.product.name} className="w-20 h-24 object-cover rounded-md bg-muted" />
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between gap-2">
                      <h4 className="font-serif text-base leading-tight">{item.product.name}</h4>
                      <button onClick={() => removeFromCart(item.product.id, item.size)} aria-label="Remove">
                        <X className="w-4 h-4 text-muted-foreground hover:text-foreground" />
                      </button>
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">Size {item.size}</div>
                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-center border border-border rounded-full">
                        <button onClick={() => updateQty(item.product.id, item.size, item.qty - 1)} className="p-1.5"><Minus className="w-3 h-3" /></button>
                        <span className="px-3 text-sm tabular-nums">{item.qty}</span>
                        <button onClick={() => updateQty(item.product.id, item.size, item.qty + 1)} className="p-1.5"><Plus className="w-3 h-3" /></button>
                      </div>
                      <div className="text-sm tabular-nums">${item.product.price * item.qty}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="border-t border-border/60 px-6 py-5 space-y-4">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="tabular-nums">${cartTotal}</span>
              </div>
              <p className="text-xs text-muted-foreground">Shipping and taxes calculated at checkout.</p>
              <Button className="w-full" size="lg" onClick={() => setCartOpen(false)} asChild>
                <Link to="/checkout">Checkout</Link>
              </Button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
};
