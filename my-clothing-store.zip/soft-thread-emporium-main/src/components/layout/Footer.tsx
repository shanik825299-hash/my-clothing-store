import { Link } from "react-router-dom";

export const Footer = () => (
  <footer className="mt-32 border-t border-border/60 bg-secondary/30">
    <div className="container-editorial py-16 grid grid-cols-2 md:grid-cols-4 gap-10">
      <div className="col-span-2">
        <div className="font-serif text-3xl tracking-wide mb-4">Maison Lune</div>
        <p className="text-sm text-muted-foreground max-w-sm leading-relaxed">
          A small, considered collection of slow-made clothing. Designed in Lisbon, made in Europe.
        </p>
      </div>
      <div>
        <div className="eyebrow mb-4">Shop</div>
        <ul className="space-y-2 text-sm text-muted-foreground">
          <li><Link to="/shop" className="hover:text-foreground">All</Link></li>
          <li><Link to="/shop?cat=Knitwear" className="hover:text-foreground">Knitwear</Link></li>
          <li><Link to="/shop?cat=Outerwear" className="hover:text-foreground">Outerwear</Link></li>
          <li><Link to="/lookbook" className="hover:text-foreground">Lookbook</Link></li>
        </ul>
      </div>
      <div>
        <div className="eyebrow mb-4">House</div>
        <ul className="space-y-2 text-sm text-muted-foreground">
          <li><Link to="/story" className="hover:text-foreground">Our story</Link></li>
          <li><a className="hover:text-foreground" href="#">Care</a></li>
          <li><a className="hover:text-foreground" href="#">Journal</a></li>
          <li><a className="hover:text-foreground" href="#">Contact</a></li>
        </ul>
      </div>
    </div>
    <div className="border-t border-border/60">
      <div className="container-editorial py-6 flex flex-col md:flex-row items-center justify-between text-xs text-muted-foreground gap-2">
        <div>© {new Date().getFullYear()} Maison Lune. All rights reserved.</div>
        <div>Made slowly, in small batches.</div>
      </div>
    </div>
  </footer>
);
