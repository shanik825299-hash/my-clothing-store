import { Link, useLocation } from "react-router-dom";
import { ShoppingBag, Heart, Sun, Moon, Search, Menu, X, User, LogOut } from "lucide-react";
import { useState } from "react";
import { useShop } from "@/context/ShopContext";
import { useAuth } from "@/context/AuthContext";
import { useTheme } from "@/hooks/useTheme";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const nav = [
  { to: "/shop", label: "Shop" },
  { to: "/lookbook", label: "Lookbook" },
  { to: "/story", label: "Story" },
  { to: "/admin", label: "Admin" },
];

export const Header = () => {
  const { cartCount, setCartOpen, wishlist } = useShop();
  const { user, signOut } = useAuth();
  const { theme, toggle } = useTheme();
  const { pathname } = useLocation();
  const [open, setOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    toast.success("Signed out.");
  };

  return (
    <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-md border-b border-border/60">
      <div className="container-editorial flex items-center justify-between h-16 md:h-20">
        <button className="md:hidden p-2 -ml-2" onClick={() => setOpen(!open)} aria-label="Menu">
          {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>

        <nav className="hidden md:flex items-center gap-8 flex-1">
          {nav.map(n => (
            <Link
              key={n.to}
              to={n.to}
              className={cn(
                "text-[13px] tracking-wide link-underline transition-colors",
                pathname === n.to ? "text-foreground" : "text-muted-foreground hover:text-foreground"
              )}
            >
              {n.label}
            </Link>
          ))}
        </nav>

        <Link to="/" className="font-serif text-2xl md:text-3xl tracking-wide absolute left-1/2 -translate-x-1/2">
          Maison Lune
        </Link>

        <div className="flex items-center gap-1 md:gap-2 flex-1 justify-end">
          <button className="hidden md:inline-flex p-2 hover:text-accent transition-colors" aria-label="Search">
            <Search className="w-[18px] h-[18px]" />
          </button>
          <button onClick={toggle} className="p-2 hover:text-accent transition-colors" aria-label="Theme">
            {theme === "light" ? <Moon className="w-[18px] h-[18px]" /> : <Sun className="w-[18px] h-[18px]" />}
          </button>
          {user ? (
            <button onClick={handleSignOut} className="p-2 hover:text-accent transition-colors" aria-label="Sign out" title={user.email ?? "Sign out"}>
              <LogOut className="w-[18px] h-[18px]" />
            </button>
          ) : (
            <Link to="/auth" className="p-2 hover:text-accent transition-colors" aria-label="Sign in">
              <User className="w-[18px] h-[18px]" />
            </Link>
          )}
          <Link to="/wishlist" className="relative p-2 hover:text-accent transition-colors" aria-label="Wishlist">
            <Heart className="w-[18px] h-[18px]" />
            {wishlist.length > 0 && (
              <span className="absolute -top-0.5 -right-0.5 bg-accent text-accent-foreground text-[10px] rounded-full w-4 h-4 flex items-center justify-center">{wishlist.length}</span>
            )}
          </Link>
          <button onClick={() => setCartOpen(true)} className="relative p-2 hover:text-accent transition-colors" aria-label="Cart">
            <ShoppingBag className="w-[18px] h-[18px]" />
            {cartCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 bg-accent text-accent-foreground text-[10px] rounded-full w-4 h-4 flex items-center justify-center">{cartCount}</span>
            )}
          </button>
        </div>
      </div>

      {open && (
        <nav className="md:hidden border-t border-border/60 px-6 py-4 flex flex-col gap-4 bg-background animate-fade-in">
          {nav.map(n => (
            <Link key={n.to} to={n.to} onClick={() => setOpen(false)} className="text-sm">
              {n.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
};
